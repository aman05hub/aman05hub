let UserScore = 0;
let CompScore = 0;

const choices = document.querySelectorAll(".choice");
const msg = document.querySelector("#msg");
const UserScorePara = document.querySelector("#user-score");
const CompScorePara = document.querySelector("#comp-score");

const getCompChoice = () => {
    const option = ["rock","scissor","paper"];
    const randIdx = Math.floor(Math.random() * 3);
    return option[randIdx];
}

const drawGame = (CompChoice) => {
    msg.innerText = `Game was Draw ! Opponent choice was same ${CompChoice}`;
    msg.style.backgroundColor = "Black";
}

const ShowWin = (userWin , CompChoice) => {
    if (userWin){
        UserScore++;
        UserScorePara.innerText = UserScore;
        msg.innerText = `You Win ! Opponent choice was ${CompChoice}`;
        msg.style.backgroundColor = "Green";
    }
    else{
        CompScore++;
        CompScorePara.innerText = CompScore;
        msg.innerText = `You Lose ! Opponent choice was ${CompChoice}`;
        msg.style.backgroundColor = "Red";
    }
}

const playGame = (UserChoice) => {
    //Computer Choice Genrate...
    const CompChoice = getCompChoice();

    if(UserChoice === CompChoice){
        //Game Draw
        drawGame(CompChoice);
    }
    else{
        let userWin = true;
        if(UserChoice === "rock"){
            //scissor,paper
            userWin = CompChoice === "paper" ? false : true;
        }
        else if(UserChoice === "paper"){
            //scissor,rock
            userWin = CompChoice === "scissor" ? false : true;
        }
        else{
            //rock,paper
            userWin = CompChoice === "rock" ? false : true;
        }
        ShowWin(userWin , CompChoice);
    }
};

choices.forEach((choice) => {
    choice.addEventListener("click",() => {
        const UserChoice = choice.getAttribute("id");
        playGame(UserChoice);
    });
});